import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.apache.commons.io.FileUtils;
import org.checkerframework.common.reflection.qual.GetClass;
import org.checkerframework.common.reflection.qual.GetMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Resources.base;
import pageObjects.MBRHEContactusObjects;

public class MBRHEContactus extends base {

	WebDriver driver;

	@BeforeMethod
	public void initialize() throws IOException {
		// to open the Web site
		driver = initializeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get(prop.getProperty("url"));
		driver.manage().window().maximize();
		// after open the Web site to click Skip in Tour and Tips

		try {
			driver.findElement(By.cssSelector(
					"body > div.introjs-tooltipReferenceLayer > div > div.introjs-tooltipbuttons > a.introjs-button.introjs-skipbutton"))
					.click();
		} catch (Exception e) {

			e.printStackTrace();
			System.out.println("please to Click on skip of Tour and tips ");
		}

	}

	@Test(priority = 1)
	public void ValidateContactus() throws InterruptedException, IOException {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4));
		// create contact us object
		MBRHEContactusObjects cu = new MBRHEContactusObjects(driver);
		// click contact us tab
		cu.contactustab().click();
		// click contact info tab
		cu.contactinfotab().click();

		// fill information - Name
		cu.EnterName().sendKeys(UserName);

		// fill information -Mobile
		cu.Entermobile().sendKeys(UserMobile);

		// fill information -Subject
		cu.Entersubject().sendKeys(UserSubject);
		// fill information -Email
		cu.Enteremail().sendKeys(Useremail);

		// open the list of Would you like customer service team to call you ? *

		WebElement scrolltomessageBox = driver.findElement(By.xpath("//*[@id=\"ContactUs\"]/div[5]/div/div/label"));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", scrolltomessageBox);

		WebElement dropdown1 = driver.findElement(By.cssSelector("#feedCall"));

		// Create a Select object
		Select select1 = new Select(dropdown1);
		select1.selectByIndex(1);

		// open and select first value of type list

		WebElement typelist = driver.findElement(By.cssSelector("#feedType"));
		Select select2 = new Select(typelist);
		select2.selectByIndex(1);

		Thread.sleep(1000);
		// scroll down to Enable Category List
		driver.findElement(By.xpath("//*[@id=\"feedReason\"]")).click();

		WebElement categorylist = driver.findElement(By.xpath("//*[@id=\"feedReason\"]"));
		Select select3 = new Select(categorylist);

		String fv = "Housing Grant";
		select3.selectByValue(fv);

//  enter message 
		cu.entermessagetext().sendKeys("test test test");

// click submit to display Security message validation

		cu.Clicksubmitbtn().click();
		Thread.sleep(9000);
//  Take a PNG Screenshot

		String TestCaseName = new Object(){}.getClass().getEnclosingMethod().getName();
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src,
				new File(System.getProperty("user.dir") + "\\src\\resources\\Screenshots\\" + TestCaseName + ".png"));
// get the Security Validation Message 
		String ActualSecurityMessagewithspaces = driver.findElement(By.xpath("//*[@id=\"captchaerrorContact\"]"))
				.getText();

		String ActualSecurityMessage = ActualSecurityMessagewithspaces.trim();
		System.out.println(ActualSecurityMessage);
		// get message to assert
		Assert.assertEquals(ActualSecurityMessage, "Security Code is Required");

		/*
		 * // to complete saving screenshot as zipFile later
		 * 
		 * File screenshotFile = ((TakesScreenshot)
		 * driver).getScreenshotAs(OutputType.FILE); // Define the path where you want
		 * to save the zip file String zipFilePath =
		 * "\\src\\resources\\ZipFilesScreenshots\\"+TestCaseName+".zip";
		 * 
		 * try { // Create a FileOutputStream for the zip file FileOutputStream fos =
		 * new FileOutputStream(zipFilePath);
		 * 
		 * // Create a ZipOutputStream ZipOutputStream zipOut = new
		 * ZipOutputStream(fos);
		 * 
		 * // Create a new entry for the screenshot file within the zip file ZipEntry
		 * zipEntry = new
		 * ZipEntry(TestCaseName+".png");//("\\src\\resources\\ZipFilesScreenshots" +
		 * TestCaseName // + ".png"); zipOut.putNextEntry(zipEntry);
		 * 
		 * // Read the screenshot file and write it to the zip file byte[] bytes = new
		 * byte[1024]; int length; FileInputStream fis = new
		 * FileInputStream(screenshotFile); while ((length = fis.read(bytes)) >= 0) {
		 * zipOut.write(bytes, 0, length); }
		 * 
		 * // Close the zip file and input stream zipOut.close(); fis.close();
		 * 
		 * // Print a message indicating where the zip file was saved
		 * System.out.println("Screenshot saved as a zip file: " + zipFilePath); } catch
		 * (IOException e) { e.printStackTrace(); }
		 * 
		 * 
		 */

	}

	@AfterTest
	public void EndScenario() throws IOException {
		driver.close();
	}

}
