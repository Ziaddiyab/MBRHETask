package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class MBRHEContactusObjects {

	public WebDriver driver;



	public MBRHEContactusObjects(WebDriver driver) {

		this.driver = driver;

	}
	
	
	//private By contactus = By.xpath("//*[text()='CONTACT US']");
	private By contactus = By.cssSelector("a.contact-link");
	
	public WebElement contactustab() {
		return driver.findElement(contactus);
	}

	
	private By contactinfo = By.xpath("//*[@id=\"step2\"]/div/ul[1]/li[4]/div/ul/li[2]/a");
	public WebElement contactinfotab() {
		return driver.findElement(contactinfo);
	}
	
	
	private By Name = By.cssSelector("input#feedId.form-control");
	public WebElement EnterName() {
		return driver.findElement(Name);
	}
	
	private By mobile = By.id("feedMobile");
	public WebElement Entermobile() {
		return driver.findElement(mobile);
	}

	private By subject = By.id("feedbackSubject");
	public WebElement Entersubject() {
		return driver.findElement(subject);
	}
	
	private By email = By.id("feedEmail");
	public WebElement Enteremail() {
		return driver.findElement(email);
	}

	private By  Categorylist = By.cssSelector("#feedReason");
	public WebElement OpenCategorylist() {
		return driver.findElement(Categorylist);
	}
	
	private By  messagetext = By.xpath("//*[@id=\"feedComment\"]");
	public WebElement entermessagetext() {
		return driver.findElement(messagetext);
	}
	private By  submitbtn = By.cssSelector("input.refresh-form-bt.rest-bt");
	public WebElement Clicksubmitbtn() {
		return driver.findElement(submitbtn);
	}
	
	private By  SecurityMessage = By.cssSelector("input.refresh-form-bt.rest-bt");
	public WebElement getSecurityMessage() {
		return driver.findElement(SecurityMessage);
	}
}
