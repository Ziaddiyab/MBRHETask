package Resources;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

public class base {
	//private static Logger log = (Logger) LogManager.getLogger(base.class.getName());// getLogger(base.class.getName());
	static WebDriver driver;

	public static String browserName;
	public static Properties prop;
	public static String UserName;
	public static String UserMobile;
	public static String Useremail;
	public static String UserSubject;


	public static WebDriver initializeDriver() throws IOException {

		prop = new Properties();
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+
				"\\src\\resources\\data.properties");

		prop.load(fis);
		
	 
		UserName=prop.getProperty("name");
		UserMobile=prop.getProperty("mobile");
		Useremail=prop.getProperty("email");
		UserSubject=prop.getProperty("subject");

		
		// String browserName = System.getProperty("browser");
		browserName = prop.getProperty("browser");
		//log.info("browser loaded");
		System.out.print(browserName);
		String webapp = prop.getProperty("url");
		//log.info("URL loaded");
		System.out.print(webapp);
		if (browserName.contains("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\work/chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			if (browserName.contains("headless")) {
				options.addArguments("--headless");
			}
			driver = new ChromeDriver(options);

		} 
		
		return driver;
	}

	public String getScreenShot(String TestCaseName, WebDriver driver) throws IOException

	{

		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String destenationFile = System.getProperty("user.dir") + "\\src\\resources\\screenshots\\" + "Screenshot of " + TestCaseName
				+ ".png";
		

		
	//	FileUtils.copyFile(src, new File(destenationFile));
		return destenationFile;

	}

}
